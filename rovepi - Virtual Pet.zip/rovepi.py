import multiprocessing
import random
import time
import os

from pytimedinput import timedInput

stage1="""                                                                                                    
                                                                                                    
                                                                                                    
               %@@@@@@@@@@@@@@@@@@@@@                                                               
               @@@                 @@@                                       @@@@@@@@               
               @@@                 @@@                                     #@@,    .@@&             
               @@@                 @@@                                     %@@      @@&             
               @@@                 @@@                                    *@@@@@@@@@@*              
               @@@                 @@@                                @@@@@@                        
               @@@                 @@@                           &@@@@@,@@@                         
               @@@                 @@@                      *@@@@@/   @@@.                          
               @@@                 @@@        .*%@@%,  .@@@@@&       @@@                            
                @@@@@@@@@@@@@@@@@@@@@@  .@@@@@@@////@@@@@@@@       /@@@                             
                                     .@@@&                @@@@    @@@                               
                                    @@@                      @@@@@@@                                
                                  @@@                          @@@%                                 
                                 #@@    ,@@@    @@@%            @@*                                 
       @@@@@@@@@@@@@@@@@@@@@@@@@@@@(    @@@@.   @@@@            &@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&    
      @@@                        @@@@@  @@.     &@@ /@@%        &@@                          #@@.   
     #@@.                       (@@@/@@@@        %@@@@@@@@      @@&                           @@@   
     @@&                        /@@@&                    @     @@@                             @@@  
    @@@                            @@@                        @@@                              (@@  
   %@@                               @@@,                  (@@@                                 @@@ 
   @@%                                 %@@@@,          /@@@@(                                    @@@
  @@@                                      *@@@@@@@@@@@@,                                        (@@
 %@@                                                                                              @@
 @@&                                                                                               @
@@@                                                                                                /
@@                                                                                                  
@%                                                                                                  
@                                                                                                   """

sleep1="""                                                                                @(                  
                                                                                                    
                                                                      @@@@@@                        
               %@@@@@@@@@@@@@@@@@@@@@                                    /@                         
               @@@                 @@@                                  @.                          
               @@@                 @@@                                &@                            
               @@@                 @@@                                                              
               @@@                 @@@                                                              
               @@@                 @@@                           %@                                 
               @@@                 @@@                          @                                   
               @@@                 @@@                        @&                                    
               @@@                 @@@        .*%@@%,        @@@@@@                                 
                @@@@@@@@@@@@@@@@@@@@@@  .@@@@@@@////@@@@@@@                                         
                                     .@@@&             && @@@@                                      
                                    @@@             @@@@*    @@@                                    
                                  @@@      @@@@    @@%         @@%                                  
                                 #@@     .@@%      (@@@&        @@*                                 
       @@@@@@@@@@@@@@@@@@@@@@@@@@@@(     @@@          ,@@       &@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&    
      @@@                        @@(     @@&                    @@@,@@@@@%                   #@@.   
     #@@.                        @@@     @@@        @@@@@      .@@&     *@@@@@#               @@@   
     @@&                          @@&     @@@    .@@@.         @@@           (@@@@@(    #@@@@@@@@@  
    @@@                            @@@     (.    &@@          @@@%  ,/%&@@@@@@@@@@@@@@@@@@    .@@@  
   %@@                               @@@,         @@@      (@@@@@@@@@@&#/.            ,@@,     @@@@ 
   @@%                                 %@@@@,      @*  /@@@@(                          *@@@@@@@@@@@@
  @@@                                      *@@@@@@@@@@@@,                                  ,*.   (@@
 %@@                                                                                              @@
 @@&                                                                                               @
@@@                                                                                                /
@@                                                                                                  
@%                                                                                                  
@                                                                                                   """
pet="""                                                                                                    
                                                                                                    
                                                                                                    
               %@@@@@@@@@@@@@@@@@@@@@                                                               
               @@@                 @@@                                       @@@@@@@@               
               @@@                 @@@                                     #@@,    .@@&             
               @@@                 @@@                                     %@@      @@&             
               @@@                 @@@                                    *@@@@@@@@@@*              
               @@@                 @@@                                @@@@@@                        
               @@@                 @@@                           &@@@@@,@@@                         
               @@@                 @@@                      *@@@@@/   @@@.                          
               @@@                 @@@        .*%@@%,  .@@@@@&       @@@                            
                @@@@@@@@@@@@@@@@@@@@@@  .@@@@@@@////@@@@@@@@       /@@@                             
                                     .@@@&                @@@@    @@@                               
                                    @@@                      @@@@@@@                                
                                  @@@ @@@                      @@@%                                 
                                 #@@   @@@   @@@@               @@*                                 
       @@@@@@@@@@@@@@@@@@@@@@@@@@@@(  @(&@@@@@.    .@@*         &@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&    
      @@@                        @@@@@@@@@@@.       @@@         &@@                          #@@.   
     #@@.                        @@@  ,@@  @.        &@@@@@@@@  @@&                           @@@   
     @@&                          @@&  @@@%        @@@@@/#&    @@@                             @@@  
    @@@                            @@@   &@@@@@&/*/%@@/@@@@@  @@@                              (@@  
   %@@                               @@@,     /&@@@&/     @&@@@                                 @@@ 
   @@%                                 %@@@@,          /@@@@(                                    @@@
  @@@                                      *@@@@@@@@@@@@,                                        (@@
 %@@                                                                                              @@
 @@&                                                                                               @
@@@                                                                                                /
@@                                                                                                  
@%                                                                                                  
@                                                                                                   """
os.system('cls')
print('Rove PI loading!')
time.sleep(2)

num = 0

while num <= 10:
    num += 1
    time.sleep(0.1)
    os.system('cls')
    print('Rove PI loading.')
    time.sleep(0.1)
    os.system('cls')
    print('Rove PI loading..')
    time.sleep(0.1)
    os.system('cls')
    print('Rove PI loading...')

os.system('cls')
print(sleep1)
answer=input('Do you wish to wake Rove up? (y/n)')

wake=False
exitted = False
food=10
answers=["yes","y"]
happy=50

while wake==False:
    if answer.lower() in answers:
        os.system('cls')
        print(stage1)
        input("Good morning, "+ os.getlogin() +"! [Enter]")
        wake=True
    if answer.lower() not in answers:
        input("Come back soon! [Enter]")
        wake="nowakey"
        exitted = True

while exitted==False:
    happy -= 1
    if happy <= 0:
        exitted = True
        os.system('cls')
        print(stage1)
        print("I'm sad now. Bye for now, "+ os.getlogin() +"...")
        time.sleep(5)
    os.system('cls')
    print(stage1)
    time.sleep(0.1)
    ans, timedOut = timedInput("[p-Pet] [f-Feed] [e-Exit]: STATS: HAP"+ str(happy) +" ENG100", 1)
    if ans.lower()=="p":
        os.system('cls')
        print(pet)
        print("<3")
        happy += 2
        if happy >= 100:
            happy = 100
        time.sleep(1)
    if ans.lower()=="f":
        if food==0:
            print("No more food.")
            time.sleep(1)
        if food>0:
            os.system('cls')
            print(pet)
            food-=1
            happy += 5
            if happy >= 100:
                happy = 100
            print("Thank you! "+ str(food) +" food remaining.")
            time.sleep(1)
    if ans.lower()=="e":
        ans=input("Are you leaving? (y to leave)")
        if ans.lower()=="y":
            exitted = True
            input("Bye, "+ os.getlogin() +"... :( [Enter]")
            input("[Enter]")